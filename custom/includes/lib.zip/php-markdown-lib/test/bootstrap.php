<?php

define('TEST_ROOT', __DIR__);
define('TEST_RESOURCES_ROOT', __DIR__ . '/resources');

require_once __DIR__ . '/helpers/MarkdownTestHelper.php';
